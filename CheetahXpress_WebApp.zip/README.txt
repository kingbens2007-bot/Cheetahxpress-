# CheetahXpress Web App

Web app statique pour CheetahXpress, connecté au storefront Shopify:
https://cheetahxpress.myshopify.com/

## Ce que l'app contient
- Branding CheetahXpress black / gold / white
- Catalogue dynamique Shopify
- Prix et images produits depuis Shopify
- Ajouter au panier
- Acheter maintenant → checkout Shopify
- Design responsive mobile/desktop
- Aucun Storefront API access token requis pour les fonctions de base utilisées ici

## Déploiement gratuit avec GitHub Pages
1. Crée un nouveau dépôt GitHub PUBLIC, par exemple `cheetahxpress-app`.
2. Mets `index.html` et `logo.png` à la racine du dépôt.
3. GitHub → Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: `main`, folder: `/root`.
6. Save.
7. Attends la publication.
8. Ton URL sera de la forme:
   `https://TON-USERNAME.github.io/cheetahxpress-app/`

Utilise cette URL comme **App Link** dans Pi App Studio.

GitHub Pages héberge directement les fichiers HTML/CSS/JavaScript d'un dépôt et est disponible avec GitHub Free pour les dépôts publics.

## Important
- Le domaine Shopify reste la boutique et le checkout.
- Le site GitHub Pages est le front-end personnalisé.
- Si tu veux afficher l'inventaire, des metafields ou des comptes clients Shopify, un public access token via le canal Headless peut être nécessaire.
